# Merman 0.5.0

Source: https://packages.typst.org/preview/merman-0.5.0.tar.gz

Archive SHA-256: `9906dafa634d600306349751d9792c4384a4d7d033da39d843873694795326c1`

Runtime files and required license notices are included for offline diagram rendering.
